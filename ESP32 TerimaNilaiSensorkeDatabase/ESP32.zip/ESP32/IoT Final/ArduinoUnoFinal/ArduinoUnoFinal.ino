#include <SoftwareSerial.h>
#include <Servo.h>

// ===== Pin Sensor HW-201 =====
const int sensorOutPin = 2; // Sensor HW untuk ORANG KELUAR
const int sensorInPin  = 4; // Sensor HW untuk ORANG MASUK

// ===== Pin Buzzer =====
const int buzzerPin = 7;

// ===== Pin Servo =====
const int servoInPin  = 9; // Servo untuk orang masuk
const int servoOutPin = 6; // Servo untuk orang keluar

// ===== Servo Object =====
Servo servoIn;
Servo servoOut;

// ===== Pin Serial Komunikasi dengan ESP32 =====
const int txPin = 11; // Arduino TX → ESP32 RX
const int rxPin = 12; // Arduino RX → ESP32 TX

// ===== Inisialisasi SoftwareSerial =====
SoftwareSerial espSerial(rxPin, txPin);

// ===== Variabel Status Sensor =====
bool personDetectedIn = false;
bool personDetectedOut = false;

// ===== Variabel Hitung Orang =====
int peopleCount = 0;

// ===== Fungsi Startup Beep Dua Kali =====
void startupBeep() {
  for (int i = 0; i < 2; i++) {
    tone(buzzerPin, 800, 100);
    delay(200);
  }
  noTone(buzzerPin);
}

// ===== Fungsi Beep Singkat (Orang Lewat) =====
void beepShort() {
  tone(buzzerPin, 850);
  delay(120);
  tone(buzzerPin, 950);
  delay(100);
  noTone(buzzerPin);
}

// ===== Fungsi Beep Ready (WiFi & API Terhubung) =====
void beepReady() {
  Serial.println("🔔 ESP32: WiFi & API tersambung (beep 3x)");
  for (int i = 0; i < 3; i++) {
    tone(buzzerPin, 850, 100);
    delay(150);
  }
  noTone(buzzerPin);
}

// ===== Fungsi Beep OK (API sukses) =====
void beepSuccess() {
  tone(buzzerPin, 900, 80);
  delay(150);
  tone(buzzerPin, 900, 80);
  delay(100);
  noTone(buzzerPin);
}

// ===== Fungsi Beep Fail (API gagal) =====
void beepFail() {
  tone(buzzerPin, 700, 200);
  delay(200);
  noTone(buzzerPin);
}

void setup() {
  Serial.begin(9600);
  espSerial.begin(9600);

  pinMode(sensorOutPin, INPUT);
  pinMode(sensorInPin, INPUT);
  pinMode(buzzerPin, OUTPUT);

  servoIn.attach(servoInPin);
  servoOut.attach(servoOutPin);

  // posisi awal servo
  servoIn.write(0);
  servoOut.write(0);

  // Efek startup beep dua kali
  startupBeep();

  Serial.println("✅ Sistem siap. Sensor, Servo, dan Buzzer aktif.");
  espSerial.println("✅ Sistem siap. Sensor, Servo, dan Buzzer aktif.");
}

void loop() {
  int sensorInState = digitalRead(sensorInPin);
  int sensorOutState = digitalRead(sensorOutPin);

  // ===== SENSOR MASUK =====
  if (sensorInState == LOW && !personDetectedIn) {
    personDetectedIn = true;
    peopleCount++;
    String msg = "Masuk=1 | Total: " + String(peopleCount);
    Serial.println(msg);
    espSerial.println(msg);
    beepShort(); // bunyi singkat saat orang masuk
    servoIn.write(90); // servo buka pintu masuk
  }

  if (sensorInState == HIGH && personDetectedIn) {
    personDetectedIn = false;
    delay(1000);
    servoIn.write(0); // tutup pintu masuk
  }

  // ===== SENSOR KELUAR =====
  if (sensorOutState == LOW && !personDetectedOut) {
    personDetectedOut = true;
    if (peopleCount > 0) {
      peopleCount--;
      String msg = "Keluar=1 | Total: " + String(peopleCount);
      Serial.println(msg);
      espSerial.println(msg);
      beepShort(); // bunyi singkat saat orang keluar
      servoOut.write(90); // servo buka pintu keluar
    } else {
      Serial.println("⚠️ Tidak ada orang untuk dikurangi.");
      espSerial.println("⚠️ Tidak ada orang.");
      beepShort();
    }
  }

  if (sensorOutState == HIGH && personDetectedOut) {
    personDetectedOut = false;
    delay(1500);
    servoOut.write(0); // tutup pintu keluar
  }

  // ===== Terima perintah dari ESP32 =====
  if (espSerial.available()) {
    String cmd = espSerial.readStringUntil('\n');
    cmd.trim();

    if (cmd == "BUZZER_OK") {
      Serial.println("🔔 ESP32: API sukses (beep 2x)");
      beepSuccess();
    } 
    else if (cmd == "BUZZER_FAIL") {
      Serial.println("🔔 ESP32: API gagal (beep 1x)");
      beepFail();
    }
    else if (cmd == "BUZZER_READY") {
      beepReady(); // bunyi 3x tanda WiFi & API tersambung
    }
  }

  delay(50);
}
