#include <WiFi.h>
#include <HTTPClient.h>

// === Pin RX/TX Komunikasi dengan Arduino ===
#define RXD2 25  // RX → Arduino TX
#define TXD2 26  // TX → Arduino RX

// === WiFi dan API ===
const char* ssid = "TOMMY GAS";
const char* password = "SHENG_TAN";
const char* apiEndpoint = "http://192.168.0.106:8000/api/sensors";

// === Variabel jumlah orang & batas maksimal ===
int peopleCount = 0;
const int maxPeople = 5; // batas maksimal orang di ruangan

// ===== Fungsi Kirim ke API =====
bool sendToAPI(String sensorName) {
  HTTPClient http;
  http.begin(apiEndpoint);
  http.addHeader("Content-Type", "application/json");

  String jsonPayload = "{\"sensor_name\":\"" + sensorName + "\",\"value\":1}";
  Serial.println("🌐 Mengirim ke API: " + jsonPayload);

  int httpResponseCode = http.POST(jsonPayload);
  bool success = (httpResponseCode == 200 || httpResponseCode == 201);

  if (success) {
    Serial.println("✅ Data berhasil dikirim ke API!");
    Serial2.println("BUZZER_OK");  // kirim ke Arduino: 2x bunyi
  } else {
    Serial.print("❌ Gagal kirim ke API. Kode respons: ");
    Serial.println(httpResponseCode);
    Serial2.println("BUZZER_FAIL");  // kirim ke Arduino: 1x bunyi
  }

  http.end();
  return success;
}

void setup() {
  Serial.begin(115200);
  Serial2.begin(9600, SERIAL_8N1, RXD2, TXD2);

  Serial.println("Menghubungkan ke WiFi...");
  WiFi.begin(ssid, password);

  int attempt = 0;
  while (WiFi.status() != WL_CONNECTED && attempt < 20) {
    delay(500);
    Serial.print(".");
    attempt++;
  }

  Serial.println();
  if (WiFi.status() == WL_CONNECTED) {
    Serial.println("✅ WiFi Terhubung!");
    Serial.print("IP ESP32: ");
    Serial.println(WiFi.localIP());

    // 🔔 Kirim perintah ke Arduino agar bunyi 3x (tanda sistem siap)
    Serial2.println("BUZZER_READY");

    // Tes koneksi ke API sekali di awal
    HTTPClient testHttp;
    testHttp.begin(apiEndpoint);
    int code = testHttp.GET();
    if (code == 200 || code == 201) {
      Serial.println("🌐 API Respons OK. Sistem siap!");
    } else {
      Serial.println("⚠️ API tidak merespons, tapi WiFi tetap terhubung.");
    }
    testHttp.end();
  } else {
    Serial.println("⚠️ Gagal konek WiFi!");
  }

  Serial.println("ESP32 siap menerima data dari Arduino...");
  Serial.println("--------------------------------------------");
}

void loop() {
  if (Serial2.available()) {
    String data = Serial2.readStringUntil('\n');
    data.trim();

    if (data.length() > 0) {
      Serial.print("📥 Data dari Arduino: ");
      Serial.println(data);

      // ===== Logika MASUK dengan maxPeople =====
      if (data.startsWith("Masuk=1")) {
        if (peopleCount < maxPeople) {
          peopleCount++;
          Serial.print("🟢 Orang MASUK. Total: ");
          Serial.println(peopleCount);
          sendToAPI("masuk");
        } else {
          Serial.println("🚫 Ruangan penuh! Orang tidak bisa masuk.");
          Serial2.println("BUZZER_FULL"); // beri perintah bunyi penuh di Arduino
        }
      } 
      // ===== Logika KELUAR =====
      else if (data.startsWith("Keluar=1")) {
        if (peopleCount > 0) peopleCount--;
        Serial.print("🔵 Orang KELUAR. Total: ");
        Serial.println(peopleCount);
        sendToAPI("keluar");
      }
    }
  }

  delay(50);
}
